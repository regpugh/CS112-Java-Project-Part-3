import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Driver {

    private static List<String> getRecordFromLine(String line) {
        List<String> values = new ArrayList<String>();
        try (Scanner rowScanner = new Scanner(line)) {
            rowScanner.useDelimiter(",");
            while (rowScanner.hasNext()) {
                values.add(rowScanner.next());
            }
        }
        return values;
    }

    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<DataPoint> set = new ArrayList<DataPoint>();
        ArrayList<DataPoint> trainSet = new ArrayList<DataPoint>();
        ArrayList<DataPoint> testSet = new ArrayList<DataPoint>();
        try (Scanner scanner = new Scanner(new File("titanic.csv"));) {
            int line = 0;
            while (scanner.hasNextLine()) {
                List<String> records = getRecordFromLine(scanner.nextLine());
                // TODO: Select the columns from the records and create a DataPoint object
                // TODO: Store the DataPoint object in a collection
                if(line != 0){
                    try{
                        DataPoint p = new DataPoint(Double.parseDouble(records.get(5)), Double.parseDouble(records.get(6)), records.get(1), "");
                        set.add(p);
                    }
                    catch(Exception e){
                        continue;
                    }
                }
                line++;
            }
        }
        for(DataPoint p : set){
            Random rand = new Random();
            double randNum = rand.nextDouble();
            if (randNum < 0.9) {
                // Set the type of DataPoint as “train” and put into the Collection
                p.setType("train");
                trainSet.add(p);
            } else {
                // Set the type of DataPoint as “test” and put into the Collection
                p.setType("test");
                testSet.add(p);
            }
        }
        KNNModel model = new KNNModel(2);
        model.train(trainSet);
        System.out.println(model.test(testSet));
        double accuracy = model.getAccuracy(testSet);
        double precision = model.getPrecision(testSet);
        String acc = String.format("%10s : %2.2f", "Accuracy", accuracy);
        String pre = String.format("%10s : %2.2f", "Precision", precision);
        JFrame frame = new JFrame("Statistics");  
        JPanel panel = new JPanel();  
        panel.setLayout(new FlowLayout());  
        JLabel label = new JLabel(acc); 
        panel.add(label);   
        label = new JLabel(pre); 
        panel.add(label);  
        frame.add(panel);  
        frame.setSize(200, 300);  
        frame.setLocationRelativeTo(null);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true); 
    }
    
}
